'use client'

import { useState } from 'react'
import Link from 'next/link'
import { ArrowRight } from 'lucide-react'

export default function CaseStudies() {
  const [filter, setFilter] = useState('all')

  const cases = [
    {
      id: 1,
      title: 'Pre-raise critical findings: IAM chain to full data exfiltration',
      category: 'fintech',
      tags: ['FinTech', 'Series A · 2024'],
      desc: 'Three misconfigurations, one attack chain. Found 11 days before a $12M close.',
      findings: { critical: 2, high: 4, med: 7 },
    },
    {
      id: 2,
      title: 'Multi-tenant isolation failure: one customer could read another\'s data',
      category: 'saas',
      tags: ['B2B SaaS', 'Seed · 2024'],
      desc: 'A missing authorization check at the API level. The kind of thing a fast sprint introduces and a compliance audit never catches.',
      findings: { critical: 1, high: 3, med: 5 },
    },
    {
      id: 3,
      title: 'Supply chain attack path through CI/CD: code execution on production',
      category: 'infra',
      tags: ['Infrastructure', 'Series B · 2023'],
      desc: 'Hardcoded secrets in build artifacts, 847 days old. One pull request from production deployment compromise.',
      findings: { critical: 1, high: 6, med: 9 },
    },
    {
      id: 4,
      title: 'Patient data exposure via unauthenticated S3 presigned URL generation',
      category: 'health',
      tags: ['HealthTech', 'Series A · 2024'],
      desc: 'An API endpoint that generated permanent presigned URLs for sensitive documents — accessible to anyone with the URL, no auth required.',
      findings: { critical: 2, high: 5, med: 4 },
    },
    {
      id: 5,
      title: 'OAuth misconfiguration allowing account takeover at scale',
      category: 'saas',
      tags: ['B2B SaaS', 'Growth · 2023'],
      desc: 'A subtle flaw in the OAuth state parameter validation allowed an attacker to take over any user account with one click via a crafted link.',
      findings: { critical: 1, high: 2, med: 8 },
    },
    {
      id: 6,
      title: 'KYC document exfiltration via IDOR in document retrieval API',
      category: 'fintech',
      tags: ['FinTech', 'Series B · 2023'],
      desc: 'Sequential integer IDs in the document retrieval endpoint. No access control validation. Every customer\'s KYC documents accessible by guessing IDs.',
      findings: { critical: 1, high: 4, med: 6 },
    },
  ]

  const filtered = filter === 'all' ? cases : cases.filter(c => c.category === filter)

  const categories = [
    { value: 'all', label: 'All Industries' },
    { value: 'fintech', label: 'FinTech' },
    { value: 'saas', label: 'B2B SaaS' },
    { value: 'infra', label: 'Infrastructure' },
    { value: 'health', label: 'HealthTech' },
  ]

  return (
    <main>
      {/* Hero */}
      <section className="pt-32 pb-20 px-6 bg-gradient-to-b from-white to-muted">
        <div className="max-w-7xl mx-auto">
          <div className="inline-block bg-primary/10 text-primary px-4 py-2 rounded-full text-sm font-semibold mb-6">
            Engagements
          </div>
          <h1 className="text-5xl md:text-6xl font-bold mb-6 text-foreground leading-tight">
            What attackers found<br/>
            <span className="text-primary">before attackers found it.</span>
          </h1>
          <p className="text-lg text-muted-foreground mb-8 max-w-2xl">
            Every case study is a real engagement. Names and identifying details are anonymized at client request. The findings, however, are entirely real.
          </p>
        </div>
      </section>

      {/* Featured Case */}
      <section className="py-20 px-6 bg-white">
        <div className="max-w-7xl mx-auto">
          <div className="grid md:grid-cols-2 gap-12 items-center">
            <div className="bg-gray-300 rounded-xl aspect-video"></div>
            <div>
              <p className="text-primary font-semibold text-sm mb-2">Featured Case Study</p>
              <h2 className="text-4xl font-bold mb-6">
                Three paths to full customer data exfiltration — found 11 days before a $12M raise
              </h2>
              <p className="text-muted-foreground mb-4">
                A Hyderabad-based FinTech had passed internal security review and received a clean pen test report from their previous vendor. Eleven days before closing Series A, they engaged us for a second opinion. We found a privilege escalation chain that would have given any attacker read access to all customer financial records within 4 hours of initial foothold.
              </p>
              
              <div className="grid grid-cols-3 gap-6 my-8 py-8 border-y border-border">
                <div>
                  <p className="text-2xl font-bold text-primary">3</p>
                  <p className="text-sm text-muted-foreground">Critical paths identified</p>
                </div>
                <div>
                  <p className="text-2xl font-bold text-primary">9d</p>
                  <p className="text-sm text-muted-foreground">Engagement duration</p>
                </div>
                <div>
                  <p className="text-2xl font-bold text-primary">11d</p>
                  <p className="text-sm text-muted-foreground">Before funding close</p>
                </div>
              </div>

              <div className="bg-primary/5 p-6 rounded-xl mb-8 border-l-4 border-primary">
                <p className="text-sm text-muted-foreground mb-2 font-semibold">Primary Finding</p>
                <h4 className="font-bold mb-2">IAM Privilege Escalation → Full DB Read Access</h4>
                <p className="text-sm text-muted-foreground">
                  Overpermissioned service role in production environment. Combined with a second misconfiguration in the API gateway, an attacker with a low-privilege credential could assume a role with unrestricted read access to the customer data bucket within a 4-step chain.
                </p>
              </div>

              <a href="#" className="bg-primary text-white px-8 py-3 rounded-lg hover:opacity-90 transition inline-flex items-center gap-2">
                Read Full Case Study <ArrowRight size={20} />
              </a>
            </div>
          </div>
        </div>
      </section>

      {/* All Cases */}
      <section className="py-20 px-6 bg-muted">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-12">
            <div className="inline-block bg-primary/10 text-primary px-4 py-2 rounded-full text-sm font-semibold mb-4">
              All Engagements
            </div>
            <h2 className="text-4xl font-bold mb-4">Every engagement, every finding</h2>
            <p className="text-muted-foreground max-w-2xl mx-auto">
              Sorted by severity. The pattern is always the same: the assumptions that felt safest were the ones that weren't.
            </p>
          </div>

          {/* Filters */}
          <div className="flex gap-3 mb-12 overflow-x-auto pb-4">
            {categories.map(cat => (
              <button
                key={cat.value}
                onClick={() => setFilter(cat.value)}
                className={`px-4 py-2 rounded-full font-semibold transition whitespace-nowrap ${
                  filter === cat.value
                    ? 'bg-primary text-white'
                    : 'bg-white text-foreground hover:bg-gray-100'
                }`}
              >
                {cat.label}
              </button>
            ))}
          </div>

          {/* Cases Grid */}
          <div className="grid md:grid-cols-2 gap-8">
            {filtered.map(caseItem => (
              <div key={caseItem.id} className="bg-white rounded-xl overflow-hidden border border-border hover:shadow-lg transition">
                <div className="bg-gray-300 h-48"></div>
                <div className="p-6">
                  <div className="flex gap-2 mb-4">
                    {caseItem.tags.map((tag, i) => (
                      <span
                        key={i}
                        className={`text-xs px-3 py-1 rounded-full font-semibold ${
                          tag.includes('FinTech') ? 'bg-blue-100 text-blue-700' :
                          tag.includes('B2B') ? 'bg-red-100 text-red-700' :
                          tag.includes('Infrastructure') ? 'bg-blue-100 text-blue-700' :
                          tag.includes('HealthTech') ? 'bg-red-100 text-red-700' :
                          'bg-gray-100 text-gray-700'
                        }`}
                      >
                        {tag}
                      </span>
                    ))}
                  </div>
                  <h3 className="text-xl font-bold mb-3">{caseItem.title}</h3>
                  <p className="text-muted-foreground text-sm mb-6">{caseItem.desc}</p>
                  
                  <div className="flex gap-3 mb-6">
                    <span className="text-xs bg-red-100 text-red-700 px-3 py-1 rounded-full font-semibold">
                      {caseItem.findings.critical} Critical
                    </span>
                    <span className="text-xs bg-orange-100 text-orange-700 px-3 py-1 rounded-full font-semibold">
                      {caseItem.findings.high} High
                    </span>
                    <span className="text-xs bg-yellow-100 text-yellow-700 px-3 py-1 rounded-full font-semibold">
                      {caseItem.findings.med} Med
                    </span>
                  </div>

                  <a href="#" className="text-primary font-semibold text-sm hover:opacity-70 transition flex items-center gap-2">
                    Read Case Study <ArrowRight size={16} />
                  </a>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="py-20 px-6 bg-primary text-white">
        <div className="max-w-2xl mx-auto text-center">
          <div className="inline-block bg-white/20 text-white px-4 py-2 rounded-full text-sm font-semibold mb-6">
            Your Company
          </div>
          <h2 className="text-4xl md:text-5xl font-bold mb-6">
            Which pattern matches your stack?
          </h2>
          <p className="text-lg mb-8 opacity-90">
            Every one of these companies thought they were secure. The assumptions that made them vulnerable were invisible until we looked for them.
          </p>
          <a 
            href="https://calendly.com/securefounders/security-assumptions-review"
            target="_blank"
            className="bg-white text-primary px-8 py-3 rounded-lg hover:opacity-90 transition font-semibold inline-block"
          >
            Find Out What Would Break
          </a>
        </div>
      </section>
    </main>
  )
}
