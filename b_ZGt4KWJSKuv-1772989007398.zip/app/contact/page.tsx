'use client'

import { useState } from 'react'
import Link from 'next/link'
import { Mail, MapPin, Linkedin, CheckCircle2 } from 'lucide-react'

export default function Contact() {
  const [formSubmitted, setFormSubmitted] = useState(false)
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    company: '',
    stage: '',
    interest: '',
    message: '',
  })

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    const { name, value } = e.target
    setFormData(prev => ({ ...prev, [name]: value }))
  }

  const handleSubmit = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault()
    // Here you would typically send the form data to a backend
    console.log('Form submitted:', formData)
    setFormSubmitted(true)
    setTimeout(() => setFormSubmitted(false), 5000)
    setFormData({ name: '', email: '', company: '', stage: '', interest: '', message: '' })
  }

  return (
    <main>
      {/* Hero */}
      <section className="pt-32 pb-20 px-6 bg-gradient-to-b from-white to-muted">
        <div className="max-w-7xl mx-auto">
          <div className="inline-block bg-primary/10 text-primary px-4 py-2 rounded-full text-sm font-semibold mb-6">
            Get in Touch
          </div>
          <h1 className="text-5xl md:text-6xl font-bold mb-6 text-foreground leading-tight">
            Let's talk about<br/>
            <span className="text-primary">what would break.</span>
          </h1>
          <p className="text-lg text-muted-foreground mb-8 max-w-2xl">
            No intake forms. No pre-screening calls with an account manager. You talk to us directly.
          </p>
        </div>
      </section>

      {/* Contact Section */}
      <section className="py-20 px-6 bg-white">
        <div className="max-w-7xl mx-auto">
          <div className="grid md:grid-cols-3 gap-12">
            {/* Form */}
            <div className="md:col-span-2">
              <div className="inline-block bg-primary/10 text-primary px-4 py-2 rounded-full text-sm font-semibold mb-6">
                Send a Message
              </div>
              <h2 className="text-4xl font-bold mb-4">Tell us about your startup</h2>
              <p className="text-muted-foreground mb-8">
                We read every message personally. Expect a response within one business day — from someone who will actually be working on your engagement, not an SDR.
              </p>

              {formSubmitted && (
                <div className="bg-green-50 border border-green-200 rounded-lg p-6 mb-8 flex gap-3">
                  <CheckCircle2 size={24} className="text-green-600 flex-shrink-0" />
                  <div>
                    <p className="font-bold text-green-900">Message received.</p>
                    <p className="text-sm text-green-800">We'll be in touch within one business day.</p>
                  </div>
                </div>
              )}

              <form onSubmit={handleSubmit} className="space-y-6">
                <div className="grid md:grid-cols-2 gap-6">
                  <div>
                    <label htmlFor="name" className="block text-sm font-semibold mb-2">Your Name</label>
                    <input
                      type="text"
                      id="name"
                      name="name"
                      value={formData.name}
                      onChange={handleChange}
                      placeholder="Arjun Mehta"
                      required
                      className="w-full px-4 py-3 border border-border rounded-lg focus:outline-none focus:ring-2 focus:ring-primary"
                    />
                  </div>
                  <div>
                    <label htmlFor="email" className="block text-sm font-semibold mb-2">Email Address</label>
                    <input
                      type="email"
                      id="email"
                      name="email"
                      value={formData.email}
                      onChange={handleChange}
                      placeholder="arjun@startup.com"
                      required
                      className="w-full px-4 py-3 border border-border rounded-lg focus:outline-none focus:ring-2 focus:ring-primary"
                    />
                  </div>
                </div>

                <div className="grid md:grid-cols-2 gap-6">
                  <div>
                    <label htmlFor="company" className="block text-sm font-semibold mb-2">Company</label>
                    <input
                      type="text"
                      id="company"
                      name="company"
                      value={formData.company}
                      onChange={handleChange}
                      placeholder="Acme Corp"
                      required
                      className="w-full px-4 py-3 border border-border rounded-lg focus:outline-none focus:ring-2 focus:ring-primary"
                    />
                  </div>
                  <div>
                    <label htmlFor="stage" className="block text-sm font-semibold mb-2">Funding Stage</label>
                    <select
                      id="stage"
                      name="stage"
                      value={formData.stage}
                      onChange={handleChange}
                      className="w-full px-4 py-3 border border-border rounded-lg focus:outline-none focus:ring-2 focus:ring-primary"
                    >
                      <option value="">Select stage</option>
                      <option>Pre-Seed / Bootstrapped</option>
                      <option>Seed</option>
                      <option>Series A</option>
                      <option>Series B+</option>
                      <option>Growth / Pre-IPO</option>
                    </select>
                  </div>
                </div>

                <div>
                  <label htmlFor="interest" className="block text-sm font-semibold mb-2">What are you interested in?</label>
                  <select
                    id="interest"
                    name="interest"
                    value={formData.interest}
                    onChange={handleChange}
                    className="w-full px-4 py-3 border border-border rounded-lg focus:outline-none focus:ring-2 focus:ring-primary"
                  >
                    <option value="">Select an engagement type</option>
                    <option>Adversarial Security Review</option>
                    <option>Exploit Path Elimination</option>
                    <option>Continuous Adversarial Validation</option>
                    <option>Founder & Team Enablement</option>
                    <option>Not sure — help me figure it out</option>
                  </select>
                </div>

                <div>
                  <label htmlFor="message" className="block text-sm font-semibold mb-2">
                    What's keeping you up at night? <span className="text-muted-foreground text-xs">(Optional)</span>
                  </label>
                  <textarea
                    id="message"
                    name="message"
                    value={formData.message}
                    onChange={handleChange}
                    rows={5}
                    placeholder="Tell us about your stack, your concerns, what you've already tried. The more context, the better."
                    className="w-full px-4 py-3 border border-border rounded-lg focus:outline-none focus:ring-2 focus:ring-primary resize-none"
                  />
                </div>

                <button
                  type="submit"
                  className="bg-primary text-white px-8 py-3 rounded-lg hover:opacity-90 transition font-semibold w-full"
                >
                  Send Message
                </button>
                <p className="text-sm text-muted-foreground text-center">We respond within 1 business day</p>
              </form>
            </div>

            {/* Info */}
            <div className="space-y-6">
              {/* CTA Card */}
              <div className="bg-primary text-white p-8 rounded-xl">
                <div className="text-4xl mb-4">📅</div>
                <h3 className="text-xl font-bold mb-3">Book a Discovery Call</h3>
                <p className="text-sm mb-6 opacity-90">
                  30–45 minutes. Founder-only. We ask hard questions about your stack and your assumptions. You ask us anything. No pitch, no pressure.
                </p>
                <a
                  href="https://calendly.com/securefounders/security-assumptions-review"
                  target="_blank"
                  className="bg-white text-primary px-6 py-2 rounded-lg hover:opacity-90 transition font-semibold inline-block text-center w-full"
                >
                  Open Calendly
                </a>
              </div>

              {/* Direct Contacts */}
              <div className="bg-muted p-8 rounded-xl">
                <h3 className="font-bold mb-6">Direct Contact</h3>
                <ul className="space-y-4">
                  <li className="flex gap-3">
                    <Mail size={20} className="text-primary flex-shrink-0 mt-0.5" />
                    <div>
                      <p className="text-xs text-muted-foreground font-semibold mb-1">General</p>
                      <a href="mailto:hello@securefounders.com" className="text-primary hover:opacity-70 transition">
                        hello@securefounders.com
                      </a>
                    </div>
                  </li>
                  <li className="flex gap-3">
                    <Mail size={20} className="text-primary flex-shrink-0 mt-0.5" />
                    <div>
                      <p className="text-xs text-muted-foreground font-semibold mb-1">Security / Disclosure</p>
                      <a href="mailto:security@securefounders.com" className="text-primary hover:opacity-70 transition">
                        security@securefounders.com
                      </a>
                    </div>
                  </li>
                  <li className="flex gap-3">
                    <MapPin size={20} className="text-primary flex-shrink-0 mt-0.5" />
                    <div>
                      <p className="text-xs text-muted-foreground font-semibold mb-1">Office</p>
                      <a href="https://maps.app.goo.gl/6iAq5farLz53S7ux6" target="_blank" className="text-primary hover:opacity-70 transition">
                        Hyderabad, Telangana, India
                      </a>
                    </div>
                  </li>
                  <li className="flex gap-3">
                    <Linkedin size={20} className="text-primary flex-shrink-0 mt-0.5" />
                    <div>
                      <p className="text-xs text-muted-foreground font-semibold mb-1">LinkedIn</p>
                      <a href="https://linkedin.com/company/securefounders" target="_blank" className="text-primary hover:opacity-70 transition">
                        linkedin.com/company/securefounders
                      </a>
                    </div>
                  </li>
                </ul>
              </div>

              {/* Response SLA */}
              <div className="bg-muted p-8 rounded-xl">
                <h4 className="text-xs text-muted-foreground font-semibold mb-4 uppercase">What happens next</h4>
                <div className="space-y-4">
                  <div>
                    <p className="text-primary font-bold mb-1">01</p>
                    <p className="text-sm text-muted-foreground">We read your message and look at your public-facing attack surface before responding.</p>
                  </div>
                  <div>
                    <p className="text-primary font-bold mb-1">02</p>
                    <p className="text-sm text-muted-foreground">We reply with specific observations and a suggested next step — not a generic auto-reply.</p>
                  </div>
                  <div>
                    <p className="text-primary font-bold mb-1">03</p>
                    <p className="text-sm text-muted-foreground">If we think we can help, we schedule a call. If not, we'll tell you directly and suggest who might.</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Location */}
      <section className="py-20 px-6 bg-muted">
        <div className="max-w-7xl mx-auto">
          <div className="grid md:grid-cols-2 gap-12 items-center">
            <div className="bg-gray-300 rounded-xl aspect-video"></div>
            <div>
              <div className="inline-block bg-primary/10 text-primary px-4 py-2 rounded-full text-sm font-semibold mb-6">
                Where We Are
              </div>
              <h2 className="text-4xl font-bold mb-6">
                Based in Hyderabad.<br/>Working globally.
              </h2>
              <p className="text-muted-foreground mb-8">
                Our team is headquartered in Hyderabad, India. We work with startups remotely across geographies — India, Southeast Asia, Middle East, and beyond. For clients in the same timezone, we also offer on-site workshops and in-person executive briefings.
              </p>
              <a
                href="https://maps.app.goo.gl/6iAq5farLz53S7ux6"
                target="_blank"
                className="border-2 border-primary text-primary px-8 py-3 rounded-lg hover:bg-primary hover:text-white transition font-semibold inline-flex items-center gap-2"
              >
                <MapPin size={20} />
                Get Directions
              </a>
            </div>
          </div>
        </div>
      </section>
    </main>
  )
}
