import Link from 'next/link'
import { ArrowRight } from 'lucide-react'

export default function Home() {
  const stats = [
    { num: '94%', label: 'Of breaches trace to assumption gaps, not tool failures' },
    { num: '2–4wk', label: 'Full red team delivery. Not 6-month enterprise timelines' },
    { num: '100%', label: 'Direct expert access. No account managers. No ticket queues' },
    { num: '$0', label: 'Sales pressure. Diagnostic calls are substance-first, no pitch' },
  ]

  const services = [
    { num: '01', title: 'Adversarial Security Review', desc: 'Full-chain attack simulation from initial recon to data exfiltration.' },
    { num: '02', title: 'Exploit Path Elimination', desc: 'We don\'t just find the holes — we close them. Hands-on remediation.' },
    { num: '03', title: 'Continuous Adversarial Validation', desc: 'Validation that keeps pace with your velocity. Quarterly exercises.' },
    { num: '04', title: 'Founder & Team Enablement', desc: 'Adversarial expertise transfer — not awareness training.' },
  ]

  const testimonials = [
    {
      quote: 'The executive briefing changed how our entire leadership team thinks about risk. They showed us — live, in a screen share — exactly how an attacker would access every customer record we hold.',
      author: 'Arjun K.',
      role: 'Co-Founder & CTO, B2B SaaS',
    },
    {
      quote: 'We were 11 days from closing Series A. Secure Founders found three critical assumption gaps our own engineers had missed. We fixed all of them before the investor due diligence.',
      author: 'Sneha R.',
      role: 'Founder & CEO, FinTech Platform',
    },
    {
      quote: 'What I valued most: they spoke our language. Not CVE numbers and CVSS scores — business impact. Every finding was mapped to what it meant for revenue, customer trust, and regulatory exposure.',
      author: 'Dev M.',
      role: 'Founder, B2B Infrastructure',
    },
  ]

  return (
    <main>
      {/* Hero Section */}
      <section className="pt-32 pb-20 px-6" style={{ backgroundColor: '#f9f7f6' }}>
        <div className="max-w-7xl mx-auto">
          <div className="grid md:grid-cols-2 gap-12 items-center">
            <div>
              <div className="inline-block px-4 py-2 rounded-full text-sm font-semibold mb-6" style={{ backgroundColor: '#f0e5e5', color: '#7D2A2A' }}>
                Adversarial-First Security Intelligence
              </div>
              <h1 className="text-5xl md:text-6xl font-bold mb-6 leading-tight text-gray-900">
                If a capable attacker hit your startup <span style={{ color: '#7D2A2A' }}>today</span> — what would break?
              </h1>
              <p className="text-lg text-gray-600 mb-8 max-w-xl leading-relaxed">
                Most startups don't fail security audits. They fail when assumptions about their systems stop being true. We help founders identify what attackers would actually exploit.
              </p>
              <div className="flex flex-col sm:flex-row gap-4">
                <Link href="/contact" className="px-8 py-3 rounded-lg text-white font-semibold transition flex items-center gap-2 justify-center" style={{ backgroundColor: '#7D2A2A' }}>
                  Review Our Security Assumptions
                </Link>
                <Link href="/services" className="px-8 py-3 rounded-lg font-semibold transition flex items-center gap-2 justify-center border-2" style={{ borderColor: '#7D2A2A', color: '#7D2A2A' }}>
                  How It Works <ArrowRight size={20} />
                </Link>
              </div>
              <p className="text-sm text-gray-600 mt-6">
                Founder-only diagnostic • 30–45 min • No sales pitch
              </p>
            </div>
            
            <div className="p-6 rounded-xl border border-gray-300 shadow-lg" style={{ backgroundColor: '#1a1a1a' }}>
              <div className="rounded-t-lg p-4 mb-4" style={{ backgroundColor: '#7D2A2A' }}>
                <div className="flex gap-2 mb-2">
                  <div className="w-3 h-3 rounded-full" style={{ backgroundColor: '#ff5555' }}></div>
                  <div className="w-3 h-3 rounded-full bg-gray-500"></div>
                  <div className="w-3 h-3 rounded-full bg-gray-500"></div>
                </div>
                <p className="text-sm font-mono text-gray-200">threat_surface_scan.log</p>
              </div>
              <div className="space-y-3 font-mono text-sm">
                <div style={{ color: '#ff6b6b' }}>
                  <span style={{ color: '#ff5555', fontWeight: 'bold' }}>[CRIT]</span> IAM Privilege Escalation
                </div>
                <div style={{ color: '#ff6b6b' }}>
                  <span style={{ color: '#ff5555', fontWeight: 'bold' }}>[CRIT]</span> API Auth Bypass
                </div>
                <div style={{ color: '#ffa94d' }}>
                  <span style={{ color: '#ff922b', fontWeight: 'bold' }}>[HIGH]</span> S3 Misconfiguration
                </div>
                <div style={{ color: '#ffa94d' }}>
                  <span style={{ color: '#ff922b', fontWeight: 'bold' }}>[HIGH]</span> CI/CD Secret Exposure
                </div>
                <div style={{ color: '#ffd43b' }}>
                  <span style={{ color: '#f1e02d', fontWeight: 'bold' }}>[MED]</span> No Rate Limiting
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Stats Section */}
      <section className="py-16 px-6 bg-white">
        <div className="max-w-7xl mx-auto">
          <div className="grid md:grid-cols-4 gap-8">
            {stats.map((stat, i) => (
              <div key={i} className="text-center">
                <p className="text-4xl font-bold mb-2" style={{ color: '#7D2A2A' }}>{stat.num}</p>
                <p className="text-sm text-gray-600">{stat.label}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* About Section */}
      <section className="py-20 px-6" style={{ backgroundColor: '#f5f3f1' }}>
        <div className="max-w-7xl mx-auto">
          <div className="grid md:grid-cols-2 gap-12 items-center">
            <div className="bg-gray-300 rounded-xl aspect-video"></div>
            <div>
              <div className="inline-block text-sm font-semibold mb-4 bg-white px-4 py-2 rounded-full" style={{ color: '#7D2A2A' }}>
                Who We Are
              </div>
              <h2 className="text-4xl font-bold mb-6 text-gray-900">Built for founders. Operated by attackers.</h2>
              <p className="text-gray-600 mb-4 leading-relaxed">
                Secure Founders is an adversarial security intelligence firm. We don't run compliance checklists. We simulate the full attack chain — from initial foothold to data exfiltration — and show you exactly what a real adversary would do with access to your systems.
              </p>
              <p className="text-gray-600 mb-8 leading-relaxed">
                We work exclusively with startups because that's where the risk is highest and the assumptions are most dangerous. Founders deserve the same quality of security intelligence that enterprises pay millions for — compressed into weeks, not quarters.
              </p>
              <div className="flex flex-col sm:flex-row gap-4">
                <Link href="/about" className="font-semibold hover:opacity-70 transition flex items-center gap-2" style={{ color: '#7D2A2A' }}>
                  Our Story <ArrowRight size={20} />
                </Link>
                <Link href="/approach" className="font-semibold hover:opacity-70 transition" style={{ color: '#7D2A2A' }}>
                  Our Approach
                </Link>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Services Section */}
      <section className="py-20 px-6 bg-white">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-16">
            <p className="font-semibold text-sm mb-2" style={{ color: '#7D2A2A' }}>What We Do</p>
            <h2 className="text-4xl font-bold mb-4 text-gray-900">Four ways we break your defenses — so attackers can't</h2>
            <p className="text-gray-600 max-w-2xl mx-auto">
              Every engagement starts with one question: how would a real adversary compromise you right now?
            </p>
          </div>

          <div className="grid md:grid-cols-2 gap-8">
            {services.map((svc, i) => (
              <Link key={i} href="/services" className="group p-8 border border-gray-200 rounded-xl hover:shadow-lg transition" style={{ borderColor: '#e5ddd9' }}>
                <p className="text-sm font-semibold mb-2" style={{ color: '#7D2A2A' }}>0{i + 1}</p>
                <h3 className="text-xl font-bold mb-3 text-gray-900 group-hover:opacity-80 transition">{svc.title}</h3>
                <p className="text-gray-600 text-sm">{svc.desc}</p>
              </Link>
            ))}
          </div>
        </div>
      </section>

      {/* Manifesto */}
      <section className="py-20 px-6 text-white" style={{ backgroundColor: '#7D2A2A' }}>
        <div className="max-w-3xl mx-auto text-center">
          <blockquote className="text-4xl md:text-5xl font-bold leading-tight">
            Most breaches don't happen because <em>tools</em> fail.<br/>
            They happen because <em>assumptions</em> do.
          </blockquote>
        </div>
      </section>

      {/* Featured Case Study */}
      <section className="py-20 px-6 bg-white">
        <div className="max-w-7xl mx-auto">
          <div className="grid md:grid-cols-2 gap-12 items-center">
            <div className="bg-gray-300 rounded-xl aspect-video"></div>
            <div>
              <p className="font-semibold text-sm mb-2" style={{ color: '#7D2A2A' }}>Featured Engagement</p>
              <h2 className="text-4xl font-bold mb-6 text-gray-900">
                How we found 3 critical paths to full data compromise — 11 days before a $12M raise
              </h2>
              <p className="text-gray-600 mb-4 leading-relaxed">
                A Hyderabad-based FinTech was 11 days from closing their Series A when they engaged us. Their internal security team had green-lit the architecture. Our adversarial review uncovered a privilege escalation chain that would have given any attacker read access to all customer financial records within 4 hours of initial foothold.
              </p>
              
              <div className="grid grid-cols-3 gap-6 my-8 py-8 border-y border-gray-200">
                <div>
                  <p className="text-2xl font-bold" style={{ color: '#7D2A2A' }}>3</p>
                  <p className="text-sm text-gray-600">Critical paths identified</p>
                </div>
                <div>
                  <p className="text-2xl font-bold" style={{ color: '#7D2A2A' }}>9d</p>
                  <p className="text-sm text-gray-600">Assessment duration</p>
                </div>
                <div>
                  <p className="text-2xl font-bold" style={{ color: '#7D2A2A' }}>100%</p>
                  <p className="text-sm text-gray-600">Findings remediated</p>
                </div>
              </div>

              <Link href="/case-studies" className="px-8 py-3 rounded-lg text-white transition inline-flex items-center gap-2 font-semibold" style={{ backgroundColor: '#7D2A2A' }}>
                Read Full Case Study <ArrowRight size={20} />
              </Link>
            </div>
          </div>
        </div>
      </section>

      {/* Testimonials */}
      <section className="py-20 px-6" style={{ backgroundColor: '#f5f3f1' }}>
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-16">
            <p className="font-semibold text-sm mb-2" style={{ color: '#7D2A2A' }}>From Founders</p>
            <h2 className="text-4xl font-bold text-gray-900">What happens after the engagement</h2>
          </div>

          <div className="grid md:grid-cols-3 gap-8">
            {testimonials.map((tst, i) => (
              <div key={i} className="bg-white p-8 rounded-xl border border-gray-200">
                <p className="text-4xl mb-4" style={{ color: '#7D2A2A' }}>"</p>
                <p className="text-gray-800 mb-6 leading-relaxed">{tst.quote}</p>
                <div>
                  <p className="font-semibold text-gray-900">{tst.author}</p>
                  <p className="text-sm text-gray-600">{tst.role}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 px-6 text-white" style={{ backgroundColor: '#7D2A2A' }}>
        <div className="max-w-2xl mx-auto text-center">
          <h2 className="text-4xl md:text-5xl font-bold mb-6">
            Understand what would break<br/>before it matters.
          </h2>
          <p className="text-lg mb-8 opacity-90">
            If you're scaling, fundraising, or adding complexity — now is the moment assumptions quietly fail.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <a 
              href="https://calendly.com/securefounders/security-assumptions-review"
              target="_blank"
              className="bg-white px-8 py-3 rounded-lg hover:opacity-90 transition font-semibold"
              style={{ color: '#7D2A2A' }}
            >
              Book a Security Review
            </a>
            <a 
              href="https://calendly.com/securefounders/secure-founders-discovery-call"
              target="_blank"
              className="border-2 border-white text-white px-8 py-3 rounded-lg hover:bg-white/10 transition font-semibold"
            >
              Schedule Discovery Call
            </a>
          </div>
          <p className="text-sm mt-6 opacity-75">
            Founder-only • 30–45 min • No obligations • No pitch deck
          </p>
        </div>
      </section>
    </main>
  )
}
