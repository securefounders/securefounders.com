import Link from 'next/link'
import { ArrowRight, CheckCircle2 } from 'lucide-react'

export default function About() {
  const principles = [
    { num: '01', title: 'Security is Adversarial', desc: 'We simulate real attacker behavior, not theoretical compliance frameworks. We test systems the way attackers exploit them.' },
    { num: '02', title: 'Depth Beats Breadth', desc: 'We deliberately limit our client load. We\'d rather do three engagements brilliantly than ten superficially.' },
    { num: '03', title: 'Truth Over Comfort', desc: 'We deliver uncomfortable realities with clarity and empathy. Real security requires facing actual risks.' },
    { num: '04', title: 'Outcomes Over Outputs', desc: 'We don\'t get paid to write reports. We get paid to make companies more secure.' },
    { num: '05', title: 'Selective Partnership', desc: 'We turn down more work than we take. If we can\'t genuinely help, we\'ll say so directly and refer you to someone who can.' },
    { num: '06', title: 'Founder-First', desc: 'You talk to us directly. No account managers. No junior consultants doing the work while a senior signs the report.' },
  ]

  const team = [
    { role: 'Founder & Lead Adversary', name: '[ Your Name ]', bio: '12+ years in offensive security. Former red team lead at [ Company ]. Speaks at major security conferences. Has compromised systems in 40+ countries.' },
    { role: 'Cloud & Infrastructure Security', name: '[ Team Member ]', bio: 'Deep expertise in AWS, GCP and Azure attack paths. Previously secured infrastructure for two unicorn startups through Series C. OSCP, OSED certified.' },
    { role: 'Application Security', name: '[ Team Member ]', bio: 'Specialist in API security, authentication bypass, and supply chain attacks. Has reported critical vulnerabilities to 15+ companies via responsible disclosure programs.' },
  ]

  return (
    <main>
      {/* Hero */}
      <section className="pt-32 pb-20 px-6 bg-gradient-to-b from-white to-muted">
        <div className="max-w-7xl mx-auto">
          <div className="inline-block bg-primary/10 text-primary px-4 py-2 rounded-full text-sm font-semibold mb-6">
            Who We Are
          </div>
          <h1 className="text-5xl md:text-6xl font-bold mb-6 text-foreground leading-tight">
            We're the people<br/>
            <span className="text-primary">attackers don't want you talking to.</span>
          </h1>
          <p className="text-lg text-muted-foreground mb-8 max-w-2xl">
            Secure Founders is an adversarial security intelligence firm. We were built for one reason: startups are the most vulnerable, most underprepared, and most attacked companies on the planet — and most security firms treat them like an afterthought.
          </p>
        </div>
      </section>

      {/* Origin Story */}
      <section className="py-20 px-6 bg-white">
        <div className="max-w-7xl mx-auto">
          <div className="grid md:grid-cols-2 gap-12 items-center">
            <div className="bg-gray-300 rounded-xl aspect-video"></div>
            <div>
              <div className="inline-block bg-primary/10 text-primary px-4 py-2 rounded-full text-sm font-semibold mb-6">
                Our Origin
              </div>
              <h2 className="text-4xl font-bold mb-6 text-foreground">The breach that started everything</h2>
              <p className="text-muted-foreground mb-4">
                In 2018, a founder we knew — a friend — had their entire customer database exfiltrated three weeks before closing their Series B. The attacker used a chain of three vulnerabilities, none of which would have appeared on a standard vulnerability scan. All three had been introduced in the same 90-day sprint that took them from seed to growth stage.
              </p>
              <p className="text-muted-foreground mb-4">
                The deal didn't close. The company didn't survive. And the security firm they'd hired six months earlier had given them a clean report.
              </p>
              <p className="text-muted-foreground mb-6">
                That's the problem we built Secure Founders to solve. Not "security as compliance." Security as adversarial reality — the way attackers actually operate, not the way audit frameworks assume they do.
              </p>
              
              <blockquote className="bg-primary/5 p-6 rounded-xl border-l-4 border-primary italic text-foreground">
                "The question isn't whether your tools passed the test. The question is whether an attacker can find a path your tests didn't think to check."
              </blockquote>
            </div>
          </div>
        </div>
      </section>

      {/* Principles */}
      <section className="py-20 px-6 bg-muted">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-16">
            <div className="inline-block bg-primary/10 text-primary px-4 py-2 rounded-full text-sm font-semibold mb-4">
              How We Operate
            </div>
            <h2 className="text-4xl font-bold mb-4">Six principles we won't compromise on</h2>
          </div>

          <div className="grid md:grid-cols-2 gap-8">
            {principles.map((principle, i) => (
              <div key={i} className="bg-white p-8 rounded-xl border border-border">
                <p className="text-3xl font-bold text-primary mb-4">{principle.num}</p>
                <h3 className="text-xl font-bold mb-3">{principle.title}</h3>
                <p className="text-muted-foreground text-sm">{principle.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Team */}
      <section className="py-20 px-6 bg-white">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-16">
            <div className="inline-block bg-primary/10 text-primary px-4 py-2 rounded-full text-sm font-semibold mb-4">
              The Team
            </div>
            <h2 className="text-4xl font-bold mb-4">The people who will actually work on your engagement</h2>
            <p className="text-muted-foreground max-w-2xl mx-auto">
              No bait-and-switch. The people you meet on the discovery call are the people who run your engagement.
            </p>
          </div>

          <div className="grid md:grid-cols-3 gap-8">
            {team.map((member, i) => (
              <div key={i} className="border border-border rounded-xl overflow-hidden hover:shadow-lg transition">
                <div className="bg-gray-300 h-64"></div>
                <div className="p-6">
                  <p className="text-primary text-sm font-semibold mb-2">{member.role}</p>
                  <h3 className="text-xl font-bold mb-3">{member.name}</h3>
                  <p className="text-muted-foreground text-sm">{member.bio}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Recognition */}
      <section className="py-20 px-6 bg-muted">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-16">
            <div className="inline-block bg-primary/10 text-primary px-4 py-2 rounded-full text-sm font-semibold mb-4">
              Recognition & Press
            </div>
            <h2 className="text-4xl font-bold mb-4">Where we've been featured</h2>
          </div>

          <div className="grid md:grid-cols-4 gap-8">
            {[1, 2, 3, 4].map(i => (
              <div key={i} className="bg-white rounded-xl p-6 aspect-square flex items-center justify-center border border-border">
                <p className="text-muted-foreground text-center">Publication Logo</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="py-20 px-6 bg-primary text-white">
        <div className="max-w-2xl mx-auto text-center">
          <div className="inline-block bg-white/20 text-white px-4 py-2 rounded-full text-sm font-semibold mb-6">
            Work With Us
          </div>
          <h2 className="text-4xl md:text-5xl font-bold mb-6">
            We're selective. You should be too.
          </h2>
          <p className="text-lg mb-8 opacity-90">
            We turn down work that isn't a fit. If you're a startup that takes security seriously, let's talk.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <a 
              href="https://calendly.com/securefounders/security-assumptions-review"
              target="_blank"
              className="bg-white text-primary px-8 py-3 rounded-lg hover:opacity-90 transition font-semibold"
            >
              Book a Call
            </a>
            <Link 
              href="/contact"
              className="border-2 border-white text-white px-8 py-3 rounded-lg hover:bg-white/10 transition font-semibold"
            >
              Send a Message
            </Link>
          </div>
        </div>
      </section>
    </main>
  )
}
