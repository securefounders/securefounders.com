import Link from 'next/link'
import { ArrowRight, CheckCircle2 } from 'lucide-react'

export default function Services() {
  const services = [
    {
      num: '01',
      title: 'Adversarial Security Review',
      subtitle: 'Realistic attack simulations that expose actual compromise paths',
      desc: 'We operate the way real attackers do — without artificial scope constraints that attackers would ignore. Real breaches use multiple vulnerabilities in sequence. We trace the complete chain from initial access through full data exfiltration, then show you every step in a live executive briefing.',
      tags: ['Red Team', 'Point-in-Time', '2–4 Weeks'],
      deliverables: [
        'External attack simulation across your full stack',
        'Internal lateral movement analysis',
        'Business impact mapping for every finding',
        'Fix-first remediation roadmap with priorities',
        'Executive live briefing with exploit demonstration',
        '30-day remediation support window',
      ],
    },
    {
      num: '02',
      title: 'Exploit Path Elimination',
      subtitle: 'Systematic elimination of exploit paths through architecture redesign',
      desc: 'Finding problems without fixing them is irresponsible. We bridge the gap between identification and resolution through hands-on implementation, not consultant recommendations that land in a backlog and never get prioritized.',
      tags: ['Remediation', 'Hands-On', '3–6 Weeks'],
      deliverables: [
        'Identity and access management redesign',
        'Cloud infrastructure security corrections',
        'Application and API hardening',
        'Architectural security enhancements',
        'Validation testing confirming exploit paths closed',
        'Maintenance runbooks and documentation',
      ],
    },
    {
      num: '03',
      title: 'Continuous Adversarial Validation',
      subtitle: 'Validation that keeps pace with your velocity',
      desc: 'Startups aren\'t static. Every sprint introduces new code paths. Every quarter brings infrastructure changes, new integrations, new employees with new access. A point-in-time assessment goes stale. Our retainer keeps adversarial validation in lockstep with your product.',
      tags: ['Retainer', 'Ongoing', 'Quarterly Exercises'],
      deliverables: [
        'Quarterly red team exercises on new features and changes',
        'Monthly executive security briefings',
        'Pre-launch validation for major product releases',
        'Continuous drift detection and posture monitoring',
        'Unlimited strategic advisory access',
        'Incident response support',
      ],
    },
    {
      num: '04',
      title: 'Founder & Team Enablement',
      subtitle: 'Adversarial expertise transfer — not awareness training',
      desc: 'Closed-door programs built from real red team findings. Not slide decks with phishing statistics. We transfer the adversarial mindset we use in engagements directly to your leadership team and engineers through hands-on exercises grounded in your actual systems.',
      tags: ['Workshop', 'Closed-Door', 'Bespoke'],
      deliverables: [
        'Executive security workshops for leadership and board',
        'Secure development enablement for engineering teams',
        'VC portfolio security programs',
        'Incident response planning and tabletop exercises',
        'Threat modeling and architecture review sessions',
      ],
    },
  ]

  const process = [
    { num: '01', icon: '📞', title: 'Discovery Call', desc: '30–45 min with the founder. We learn your stack, your growth stage, and what keeps you up at night. No pitch. No template questionnaire.' },
    { num: '02', icon: '🗺️', title: 'Scope & Kickoff', desc: 'We define engagement scope together — no artificial limits. Secure access is established and attack surface mapping begins within 48 hours.' },
    { num: '03', icon: '🕵️', title: 'Adversarial Execution', desc: 'We operate like a real attacker. Full-chain simulation: initial access, lateral movement, privilege escalation, data exfiltration.' },
    { num: '04', icon: '📊', title: 'Executive Briefing', desc: 'Live demonstration of every critical finding — not a PDF. Board-ready communication of business impact, not CVE numbers.' },
    { num: '05', icon: '🔧', title: 'Remediation Support', desc: 'We stay engaged through the fix cycle. Every remediation is validated. We close the loop — not just the report.' },
  ]

  return (
    <main>
      {/* Hero */}
      <section className="pt-32 pb-20 px-6" style={{ backgroundColor: '#f9f7f6' }}>
        <div className="max-w-7xl mx-auto">
          <div className="inline-block px-4 py-2 rounded-full text-sm font-semibold mb-6" style={{ backgroundColor: '#f0e5e5', color: '#7D2A2A' }}>
            What We Do
          </div>
          <h1 className="text-5xl md:text-6xl font-bold mb-6 leading-tight text-gray-900">
            Four engagements.<br/>
            <span style={{ color: '#7D2A2A' }}>Zero assumptions left standing.</span>
          </h1>
          <p className="text-lg text-gray-600 mb-8 max-w-2xl leading-relaxed">
            We don't start with tools. We start with one question: how would a real, capable adversary compromise you right now? Everything flows from that.
          </p>
        </div>
      </section>

      {/* Services */}
      {services.map((service, idx) => (
        <section key={idx} className={`py-20 px-6 ${idx % 2 === 0 ? 'bg-white' : ''}`} style={idx % 2 === 1 ? { backgroundColor: '#f5f3f1' } : {}}>
          <div className="max-w-7xl mx-auto">
            <div className={`grid md:grid-cols-2 gap-12 items-start ${idx % 2 === 1 ? 'md:flex-row-reverse' : ''}`}>
              {idx % 2 === 0 ? (
                <>
                  <div>
                    <p className="text-sm font-semibold mb-2" style={{ color: '#7D2A2A' }}>Engagement Type</p>
                    <div className="flex gap-2 mb-6 flex-wrap">
                      {service.tags.map((tag, i) => (
                        <span key={i} className="px-3 py-1 rounded-full text-sm font-semibold" style={{ backgroundColor: '#f0e5e5', color: '#7D2A2A' }}>
                          {tag}
                        </span>
                      ))}
                    </div>
                    <div className="bg-gray-300 rounded-xl aspect-video mb-6"></div>
                  </div>
                  <div>
                    <div className="text-5xl font-bold mb-4" style={{ color: '#7D2A2A' }}>{service.num}</div>
                    <h2 className="text-4xl font-bold mb-4 text-gray-900">{service.title}</h2>
                    <h3 className="text-xl text-gray-600 mb-6">{service.subtitle}</h3>
                    <p className="text-gray-600 mb-6 leading-relaxed">{service.desc}</p>
                    
                    <div className="p-8 rounded-xl mb-8" style={{ backgroundColor: '#f0e5e5' }}>
                      <h4 className="font-bold mb-4 text-gray-900">What's Included</h4>
                      <ul className="space-y-3">
                        {service.deliverables.map((del, i) => (
                          <li key={i} className="flex gap-3 items-start">
                            <CheckCircle2 size={20} className="flex-shrink-0 mt-0.5" style={{ color: '#7D2A2A' }} />
                            <span className="text-gray-700">{del}</span>
                          </li>
                        ))}
                      </ul>
                    </div>
                    
                    <Link href="/contact" className="px-8 py-3 rounded-lg text-white transition inline-flex items-center gap-2 font-semibold" style={{ backgroundColor: '#7D2A2A' }}>
                      Start Engagement <ArrowRight size={20} />
                    </Link>
                  </div>
                </>
              ) : (
                <>
                  <div>
                    <div className="text-5xl font-bold mb-4" style={{ color: '#7D2A2A' }}>{service.num}</div>
                    <h2 className="text-4xl font-bold mb-4 text-gray-900">{service.title}</h2>
                    <h3 className="text-xl text-gray-600 mb-6">{service.subtitle}</h3>
                    <p className="text-gray-600 mb-6 leading-relaxed">{service.desc}</p>
                    
                    <div className="p-8 rounded-xl mb-8" style={{ backgroundColor: '#f0e5e5' }}>
                      <h4 className="font-bold mb-4 text-gray-900">What's Included</h4>
                      <ul className="space-y-3">
                        {service.deliverables.map((del, i) => (
                          <li key={i} className="flex gap-3 items-start">
                            <CheckCircle2 size={20} className="flex-shrink-0 mt-0.5" style={{ color: '#7D2A2A' }} />
                            <span className="text-gray-700">{del}</span>
                          </li>
                        ))}
                      </ul>
                    </div>
                    
                    <Link href="/contact" className="px-8 py-3 rounded-lg text-white transition inline-flex items-center gap-2 font-semibold" style={{ backgroundColor: '#7D2A2A' }}>
                      Start Engagement <ArrowRight size={20} />
                    </Link>
                  </div>
                  <div>
                    <p className="text-sm font-semibold mb-2" style={{ color: '#7D2A2A' }}>Engagement Type</p>
                    <div className="flex gap-2 mb-6 flex-wrap">
                      {service.tags.map((tag, i) => (
                        <span key={i} className="px-3 py-1 rounded-full text-sm font-semibold" style={{ backgroundColor: '#f0e5e5', color: '#7D2A2A' }}>
                          {tag}
                        </span>
                      ))}
                    </div>
                    <div className="bg-gray-300 rounded-xl aspect-video mb-6"></div>
                  </div>
                </>
              )}
            </div>
          </div>
        </section>
      ))}

      {/* Process */}
      <section className="py-20 px-6 bg-white">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-16">
            <p className="font-semibold text-sm mb-2" style={{ color: '#7D2A2A' }}>How an Engagement Works</p>
            <h2 className="text-4xl font-bold mb-4 text-gray-900">From first call to final briefing</h2>
          </div>

          <div className="grid md:grid-cols-5 gap-6">
            {process.map((step, i) => (
              <div key={i} className="p-6 rounded-xl" style={{ backgroundColor: '#f5f3f1' }}>
                <p className="text-4xl mb-4">{step.icon}</p>
                <p className="font-bold text-2xl mb-2" style={{ color: '#7D2A2A' }}>{step.num}</p>
                <h3 className="font-bold mb-3 text-gray-900">{step.title}</h3>
                <p className="text-sm text-gray-600">{step.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="py-20 px-6 text-white" style={{ backgroundColor: '#7D2A2A' }}>
        <div className="max-w-2xl mx-auto text-center">
          <h2 className="text-4xl md:text-5xl font-bold mb-6">
            Not sure which engagement fits? Let's figure it out together.
          </h2>
          <p className="text-lg mb-8 opacity-90">
            Every startup's threat model is different. Book a 30-minute discovery call and we'll be direct about what you need.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <a 
              href="https://calendly.com/securefounders/security-assumptions-review"
              target="_blank"
              className="bg-white px-8 py-3 rounded-lg hover:opacity-90 transition font-semibold"
              style={{ color: '#7D2A2A' }}
            >
              Book Discovery Call
            </a>
            <Link 
              href="/contact"
              className="border-2 border-white text-white px-8 py-3 rounded-lg hover:bg-white/10 transition font-semibold"
            >
              Send a Message
            </Link>
          </div>
          <p className="text-sm mt-6 opacity-75">
            Founder-only • No obligations • No pitch
          </p>
        </div>
      </section>
    </main>
  )
}
