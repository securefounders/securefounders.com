import Link from 'next/link'
import { ArrowRight, CheckCircle2, XCircle } from 'lucide-react'

export default function Approach() {
  const mindset = [
    { icon: '🔍', title: 'Reconnaissance First', desc: 'Before touching a system, we map everything a real attacker would know from the outside: exposed services, tech stack fingerprinting, employee information, third-party integrations.' },
    { icon: '⛓️', title: 'Chain Thinking', desc: 'Real breaches chain low-severity issues together. A misconfigured S3 bucket alone is informational. Combined with a JWT weakness and an overpermissioned service role, it becomes a path to full database exfiltration.' },
    { icon: '💼', title: 'Business Impact Orientation', desc: 'Every finding is evaluated against one question: what could an attacker do with this? Not "what\'s the CVSS score?" but "does this reach customer data?"' },
    { icon: '⏱️', title: 'Time-to-Compromise', desc: 'We measure and communicate how long it would take a real attacker to achieve each impact. "This finding enables full data exfiltration within 4 hours of initial access" is more useful than any severity score.' },
  ]

  const principles = [
    { num: '01', title: 'Security is Adversarial', desc: 'We simulate real attacker behavior. No artificial constraints. No theoretical frameworks that ignore what attackers actually do.' },
    { num: '02', title: 'Depth Beats Breadth', desc: 'We limit our client load deliberately. Three engagements done brilliantly is worth more than ten done superficially.' },
    { num: '03', title: 'Truth Over Comfort', desc: 'We deliver uncomfortable realities. Real security requires facing actual risks — not receiving a clean report that makes everyone feel better.' },
    { num: '04', title: 'Outcomes Over Outputs', desc: 'We stay engaged through remediation. We close the loop — not just the report. Improved posture, not delivered documentation.' },
    { num: '05', title: 'Selective Partnership', desc: 'We turn down more than we accept. If we can\'t genuinely help, we say so and refer you to someone who can.' },
    { num: '06', title: 'Founder-Centric', desc: 'You talk to us directly. The person on the discovery call is the person running the engagement. No bait and switch.' },
  ]

  const comparison = [
    { aspect: 'Starting point', bad: 'What does the framework require?', good: 'How would an attacker compromise this?' },
    { aspect: 'Scope', bad: 'Defined by contract', good: 'Defined by the attacker\'s reality' },
    { aspect: 'Findings', bad: 'Isolated vulnerabilities + CVSS scores', good: 'Complete attack chains with business impact' },
    { aspect: 'Deliverable', bad: 'PDF report for the compliance file', good: 'Live briefing + remediation partnership' },
    { aspect: 'Outcome', bad: 'Certificate of compliance', good: 'Measurably improved security posture' },
  ]

  return (
    <main>
      {/* Hero */}
      <section className="pt-32 pb-20 px-6 bg-gradient-to-b from-white to-muted">
        <div className="max-w-7xl mx-auto">
          <div className="inline-block bg-primary/10 text-primary px-4 py-2 rounded-full text-sm font-semibold mb-6">
            Our Philosophy
          </div>
          <h1 className="text-5xl md:text-6xl font-bold mb-6 text-foreground leading-tight">
            Security isn't procedural.<br/>
            <span className="text-primary">It's adversarial.</span>
          </h1>
          <p className="text-lg text-muted-foreground mb-8 max-w-2xl">
            Every other security approach starts from the assumption that defenders define the rules. Attackers don't follow rules. We start from where attackers start.
          </p>
        </div>
      </section>

      {/* Compliance Trap */}
      <section className="py-20 px-6 bg-white">
        <div className="max-w-7xl mx-auto">
          <div className="grid md:grid-cols-2 gap-12 items-start">
            <div>
              <div className="inline-block bg-primary/10 text-primary px-4 py-2 rounded-full text-sm font-semibold mb-6">
                Why It Matters
              </div>
              <h2 className="text-4xl font-bold mb-6 text-foreground">The compliance trap</h2>
              <p className="text-muted-foreground mb-4">
                The dominant approach to startup security is compliance-led: get a pen test, pass a SOC 2 audit, check the boxes. This approach creates the feeling of security without the reality of it.
              </p>
              <p className="text-muted-foreground mb-4">
                Compliance frameworks are written by committees and updated slowly. Attackers adapt in days. By the time a new attack technique appears in a compliance checklist, it's already been used in thousands of breaches.
              </p>
              <p className="text-muted-foreground">
                We don't start from frameworks. We start from the question: <em>if a capable, motivated attacker wanted to compromise this company right now, what would they do?</em> That question has a different answer for every startup — and it's the only question that matters.
              </p>
            </div>

            <div className="bg-muted p-8 rounded-xl">
              <div className="space-y-6">
                {comparison.map((row, i) => (
                  <div key={i}>
                    <p className="font-bold text-sm text-muted-foreground mb-3">{row.aspect}</p>
                    <div className="space-y-2">
                      <div className="flex gap-3 items-start bg-red-50 p-3 rounded border border-red-200">
                        <XCircle size={20} className="text-red-500 flex-shrink-0 mt-0.5" />
                        <p className="text-sm">{row.bad}</p>
                      </div>
                      <div className="flex gap-3 items-start bg-green-50 p-3 rounded border border-green-200">
                        <CheckCircle2 size={20} className="text-green-600 flex-shrink-0 mt-0.5" />
                        <p className="text-sm">{row.good}</p>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Methodology Image */}
      <section className="py-16 px-6 bg-muted">
        <div className="max-w-7xl mx-auto">
          <div className="bg-gray-300 rounded-xl aspect-video"></div>
        </div>
      </section>

      {/* Mindset */}
      <section className="py-20 px-6 bg-white">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-16">
            <div className="inline-block bg-primary/10 text-primary px-4 py-2 rounded-full text-sm font-semibold mb-4">
              Our Mental Model
            </div>
            <h2 className="text-4xl font-bold mb-4">The adversarial mindset — unpacked</h2>
            <p className="text-muted-foreground max-w-2xl mx-auto">
              We think like attackers. Not because it's a clever marketing line — because it's the only model that produces accurate risk assessment.
            </p>
          </div>

          <div className="grid md:grid-cols-2 gap-8">
            {mindset.map((item, i) => (
              <div key={i} className="bg-muted p-8 rounded-xl">
                <p className="text-4xl mb-4">{item.icon}</p>
                <h3 className="text-xl font-bold mb-3">{item.title}</h3>
                <p className="text-muted-foreground text-sm">{item.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Principles */}
      <section className="py-20 px-6 bg-muted">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-16">
            <div className="inline-block bg-primary/10 text-primary px-4 py-2 rounded-full text-sm font-semibold mb-4">
              Operating Doctrine
            </div>
            <h2 className="text-4xl font-bold mb-4">Six principles we won't compromise on</h2>
          </div>

          <div className="grid md:grid-cols-3 gap-8">
            {principles.map((principle, i) => (
              <div key={i} className="bg-white p-8 rounded-xl border border-border">
                <p className="text-3xl font-bold text-primary mb-4">{principle.num}</p>
                <h3 className="text-xl font-bold mb-3">{principle.title}</h3>
                <p className="text-muted-foreground text-sm">{principle.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="py-20 px-6 bg-primary text-white">
        <div className="max-w-2xl mx-auto text-center">
          <div className="inline-block bg-white/20 text-white px-4 py-2 rounded-full text-sm font-semibold mb-6">
            Experience the Difference
          </div>
          <h2 className="text-4xl md:text-5xl font-bold mb-6">
            See the adversarial approach in practice.
          </h2>
          <p className="text-lg mb-8 opacity-90">
            Book a 30-minute call. We'll ask specific questions about your stack and share initial observations about your public attack surface. No template, no generic output.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <a 
              href="https://calendly.com/securefounders/security-assumptions-review"
              target="_blank"
              className="bg-white text-primary px-8 py-3 rounded-lg hover:opacity-90 transition font-semibold"
            >
              Book a Discovery Call
            </a>
            <Link 
              href="/case-studies"
              className="border-2 border-white text-white px-8 py-3 rounded-lg hover:bg-white/10 transition font-semibold flex items-center gap-2 justify-center"
            >
              See Our Work <ArrowRight size={20} />
            </Link>
          </div>
        </div>
      </section>
    </main>
  )
}
