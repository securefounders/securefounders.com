import Link from 'next/link'
import { Mail, MapPin, Linkedin } from 'lucide-react'

export default function Footer() {
  return (
    <footer className="text-white" style={{ backgroundColor: '#1a1a1a' }}>
      <div className="max-w-7xl mx-auto px-6 py-16">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-12 mb-12">
          <div>
            <h3 className="text-xl font-bold mb-6" style={{ color: '#7D2A2A' }}>Secure Founders</h3>
            <p className="text-gray-400 text-sm">
              Adversarial security intelligence for startups.
            </p>
          </div>
          
          <div>
            <h4 className="font-semibold mb-4">Company</h4>
            <ul className="space-y-2 text-sm text-gray-400">
              <li><Link href="/" className="hover:text-white transition">Home</Link></li>
              <li><Link href="/services" className="hover:text-white transition">Services</Link></li>
              <li><Link href="/approach" className="hover:text-white transition">Approach</Link></li>
              <li><Link href="/case-studies" className="hover:text-white transition">Case Studies</Link></li>
              <li><Link href="/about" className="hover:text-white transition">About</Link></li>
            </ul>
          </div>

          <div>
            <h4 className="font-semibold mb-4">Contact</h4>
            <ul className="space-y-3 text-sm text-gray-400">
              <li className="flex items-center gap-2">
                <Mail size={16} />
                <a href="mailto:hello@securefounders.com" className="hover:text-white transition">
                  hello@securefounders.com
                </a>
              </li>
              <li className="flex items-center gap-2">
                <MapPin size={16} />
                <span>Hyderabad, India</span>
              </li>
            </ul>
          </div>

          <div>
            <h4 className="font-semibold mb-4">Follow</h4>
            <a href="https://linkedin.com/company/securefounders" target="_blank" className="inline-block text-gray-400 hover:text-white transition">
              <Linkedin size={20} />
            </a>
          </div>
        </div>

        <div className="border-t border-gray-700 pt-8 text-sm text-gray-400 text-center">
          <p>&copy; 2024 Secure Founders. All rights reserved.</p>
        </div>
      </div>
    </footer>
  )
}
