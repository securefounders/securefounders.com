'use client'

import Link from 'next/link'
import { useState } from 'react'
import { Menu, X } from 'lucide-react'

export default function Navigation() {
  const [isOpen, setIsOpen] = useState(false)

  return (
    <nav className="fixed w-full top-0 z-50 bg-white border-b border-gray-200 shadow-sm">
      <div className="max-w-7xl mx-auto px-6 py-4">
        <div className="flex items-center justify-between">
          <Link href="/" className="text-2xl font-bold" style={{ color: '#7D2A2A' }}>
            Secure Founders
          </Link>
          
          <div className="hidden md:flex items-center gap-8">
            <Link href="/services" className="text-gray-700 hover:text-red-700 font-medium transition">Services</Link>
            <Link href="/approach" className="text-gray-700 hover:text-red-700 font-medium transition">Approach</Link>
            <Link href="/case-studies" className="text-gray-700 hover:text-red-700 font-medium transition">Case Studies</Link>
            <Link href="/about" className="text-gray-700 hover:text-red-700 font-medium transition">About</Link>
            <Link href="/contact" className="px-6 py-2 rounded-lg font-medium transition text-white" style={{ backgroundColor: '#7D2A2A' }} onMouseEnter={(e) => e.currentTarget.style.backgroundColor = '#5a1f1f'} onMouseLeave={(e) => e.currentTarget.style.backgroundColor = '#7D2A2A'}>
              Book a Call
            </Link>
          </div>

          <button 
            className="md:hidden p-2"
            onClick={() => setIsOpen(!isOpen)}
            style={{ color: '#7D2A2A' }}
          >
            {isOpen ? <X size={24} /> : <Menu size={24} />}
          </button>
        </div>

        {isOpen && (
          <div className="md:hidden mt-4 pb-4 flex flex-col gap-4 border-t border-gray-200 pt-4">
            <Link href="/services" className="text-gray-700 hover:text-red-700 font-medium transition">Services</Link>
            <Link href="/approach" className="text-gray-700 hover:text-red-700 font-medium transition">Approach</Link>
            <Link href="/case-studies" className="text-gray-700 hover:text-red-700 font-medium transition">Case Studies</Link>
            <Link href="/about" className="text-gray-700 hover:text-red-700 font-medium transition">About</Link>
            <Link href="/contact" className="px-6 py-2 rounded-lg font-medium transition text-white text-center" style={{ backgroundColor: '#7D2A2A' }}>
              Book a Call
            </Link>
          </div>
        )}
      </div>
    </nav>
  )
}
